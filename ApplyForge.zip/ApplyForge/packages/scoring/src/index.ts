import type { CandidateProfile, CanonicalJob, ScoreBreakdown } from "@applyforge/domain";
export interface ScoreWeights { title: number; skills: number; location: number; compensation: number; seniority: number; preference: number; }
const defaults: ScoreWeights = { title: .22, skills: .28, location: .12, compensation: .12, seniority: .14, preference: .12 };
const terms=(s:string)=>new Set(s.toLowerCase().match(/[a-z0-9+#.]{2,}/g) ?? []);
const overlap=(a:Set<string>,b:Set<string>)=>{ if(!a.size) return 0; let n=0; for(const x of a) if(b.has(x)) n++; return n/a.size; };
export function scoreJob(job: CanonicalJob, profile: CandidateProfile, weights: ScoreWeights=defaults): ScoreBreakdown {
 const excluded=profile.preferences.excludedCompanies?.some(c=>c.toLowerCase()===job.company.toLowerCase());
 const hardFailures=excluded?["excluded_company"]:[];
 const titleScore=Math.max(...profile.preferences.titles.map(t=>overlap(terms(t),terms(job.title))),0);
 const skillEvidence=Object.values(profile.facts).flatMap(v=>Array.isArray(v)?v:[String(v)]).join(" ");
 const skillScore=overlap(terms(job.description), terms(skillEvidence));
 const locationScore=job.remote&&profile.preferences.remote?1:profile.preferences.locations.some(l=>job.location?.toLowerCase().includes(l.toLowerCase()))?1:.25;
 const comp=job.compensation?.max; const compensationScore=!profile.preferences.minCompensation||!comp?.valueOf? .5 : comp>=profile.preferences.minCompensation?1:0;
 const seniorityScore=/senior|lead|principal|staff/i.test(job.title)? .45:1;
 const preferenceScore=job.remote===profile.preferences.remote?1:.6;
 const raw={title:titleScore,skills:skillScore,location:locationScore,compensation:compensationScore,seniority:seniorityScore,preference:preferenceScore};
 const dimensions=Object.fromEntries(Object.entries(raw).map(([k,v])=>[k,{score:Math.round(v*100),weight:weights[k as keyof ScoreWeights],rationale:`Deterministic ${k} match`,evidence:[]}])) as ScoreBreakdown["dimensions"];
 const total=hardFailures.length?0:Math.round(Object.entries(raw).reduce((s,[k,v])=>s+v*weights[k as keyof ScoreWeights],0)*100);
 return { total, dimensions, hardFailures, rubricVersion:"1.0.0" };
}
